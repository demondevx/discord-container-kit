# discord-v2-components

A modern, strongly-typed, and fluent builder API for Discord Components V2 (Containers, Sections, and Media Galleries).

This package is completely independent of `discord.js` but designed to feel like a natural extension of its official builders.

## Installation

```bash
npm install discord-v2-components
```

## Features

- **Fluent API:** Chain methods like `.accent()`, `.add()`, and `.url()` for an exceptional developer experience.
- **Strict Validation:** Automatically enforces Discord's exact API limits (e.g. maximum children, text lengths, URL formats).
- **Immutability & Safety:** Deep `.clone()` support and immutable `toJSON()` outputs guarantee safe state management.
- **Components V2 Support:** Full support for `Container`, `Section`, `TextDisplay`, `MediaGallery`, and more.

## Usage Examples

### Building a Welcome Panel (Container)

```typescript
import { Container, Section, TextDisplay, Thumbnail, ActionRow, Button } from "discord-v2-components";

const welcomePanel = new Container()
  .accent("#5865F2") // Discord Blurple
  .add(
    new Section()
      .add(
        new TextDisplay().content("# Welcome to the Server! 🎉\nWe're glad to have you here.")
      )
      .accessory(
        new Thumbnail().url("https://example.com/server-icon.png")
      ),
    new ActionRow()
      .add(
        new Button().primary("btn_rules", "Read Rules"),
        new Button().secondary("btn_roles", "Get Roles")
      )
  );

// Send the payload via discord.js
await interaction.reply({
  components: [welcomePanel.toJSON()]
});
```

### Advanced Media Gallery

```typescript
import { MediaGallery, MediaGalleryItem } from "discord-v2-components";

const gallery = new MediaGallery()
  .add(
    new MediaGalleryItem()
      .url("https://example.com/image1.png")
      .description("First Image"),
    new MediaGalleryItem()
      .url("https://example.com/image2.png")
      .spoiler()
  );
```

### Error Handling

If you exceed a limit, the builders will throw a specific `BuilderError` right when you call `toJSON()` or add the component:

```typescript
import { ActionRow, Button, BuilderError } from "discord-v2-components";

try {
  new ActionRow().add(
    new Button().primary("1", "1"),
    new Button().primary("2", "2"),
    new Button().primary("3", "3"),
    new Button().primary("4", "4"),
    new Button().primary("5", "5"),
    new Button().primary("6", "6") // Throws BuilderError!
  ).toJSON();
} catch (error) {
  if (error instanceof BuilderError) {
    console.error(`Validation failed in ${error.builderName}: ${error.message}`);
  }
}
```

## Supported Components

| Type ID | Component | Builder | Description |
|---|---|---|---|
| 1 | Action Row | `ActionRow` | Row holding buttons or a select menu. |
| 2 | Button | `Button` | Interactive buttons. |
| 3 | String Select | `StringSelect` | Text dropdowns. |
| 4 | Text Input | `TextInput` | Modals text inputs. |
| 5 | User Select | `UserSelect` | Auto-populated user dropdowns. |
| 6 | Role Select | `RoleSelect` | Auto-populated role dropdowns. |
| 7 | Mentionable Select| `MentionableSelect` | Auto-populated user/role dropdowns. |
| 8 | Channel Select | `ChannelSelect` | Auto-populated channel dropdowns. |
| 9 | Section | `Section` | Logical group of text and an accessory. |
| 10 | Text Display | `TextDisplay` | Markdown-supported text node. |
| 11 | Thumbnail | `Thumbnail` | Image thumbnail for a Section. |
| 12 | Media Gallery | `MediaGallery` | Horizontal scrolling media carousel. |
| 13 | File | `File` | File attachment display. |
| 14 | Separator | `Separator` | Visual divider line. |
| 17 | Container | `Container` | Top-level V2 layout wrapper. |

## Documentation

Hover over any method in your IDE to see full TSDoc explanations, including exact Discord API limits.

## License

MIT
